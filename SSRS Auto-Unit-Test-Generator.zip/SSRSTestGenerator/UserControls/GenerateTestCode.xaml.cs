﻿using System.Windows.Controls;
using ICSharpCode.AvalonEdit.Highlighting;
using SSRSTestGenerator.Models;
using System.Collections.Generic;
using System.Windows;

namespace SSRSTestGenerator.UserControls
{
    /// <summary>
    /// Interaction logic for GenerateTestCode.xaml
    /// </summary>
    public partial class GenerateTestCode : UserControl
    {
        #region Delegates
        public delegate void EditProject();
        public event EditProject EditedProject;

        public delegate void RibbonBarItemUpdate(object sender, List<RibbonMenuItemArgs> arg);
        public event RibbonBarItemUpdate RibbonBarItemUpdated;

        public delegate void NotifyUser(object sender, NotificationArgs arg);
        public event NotifyUser NotifyedUser;
        #endregion

        #region Setters & Getters
        private string reportName = string.Empty;
        public string ReportName
        {
            get { return reportName; }
            set { reportName = value; }
        }

        private SSRSTestGenerator.Models.ClassEnumerations.TestFrameworks testFramework = ClassEnumerations.TestFrameworks.NUnit;
        public SSRSTestGenerator.Models.ClassEnumerations.TestFrameworks TestFramework
        {
            get { return testFramework; }
            set { testFramework = value; }
        }

        private SSRSTestGenerator.Models.ClassEnumerations.CodeLanguages language = ClassEnumerations.CodeLanguages.CSharp;
        public SSRSTestGenerator.Models.ClassEnumerations.CodeLanguages Language
        {
            get { return language; }
            set { language = value; }
        }

        List<RibbonMenuItemArgs> MenuArgs { get; set; }
        App MainApp { get; set; }
        #endregion

        public GenerateTestCode()
        {
            try
            {
                InitializeComponent();

                this.MainApp = ((App)Application.Current); // reference to logging
                this.MainApp.LogMessage("Info","GenerateTestCode entered");

                this.MenuArgs = new List<RibbonMenuItemArgs>();

                if (Language == ClassEnumerations.CodeLanguages.CSharp) txtCode.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition("C#");
                else txtCode.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition("VB.NET");

                txtCode.ShowLineNumbers = true;

                this.MainApp.LogMessage("Debug", "GenerateTestCode language is " + Language.ToString());
            }
            finally
            {
                this.MainApp.LogMessage("Info","GenerateTestCode exited");
            }
        }

        #region Public Methods
        public void BindCodeToEditorBuildTreeTabSelected(string code)
        {
            try
            {
                this.MainApp.LogMessage("Info","BindCodeToEditorBuildTreeTabSelected entered");

                if (!string.IsNullOrEmpty(code))
                {
                    this.txtCode.IsEnabled = true;
                    this.txtCode.Clear();
                    this.txtCode.Text = code;

                    this.NotifyedUser(this, new NotificationArgs() { Message = this.ReportName + " - Unit tests loaded successfully", ImagePath = "/Images/16x16-Valid.png" });
                }
                else this.txtCode.IsEnabled = false;
            }
            finally
            {
                this.MainApp.LogMessage("Info","BindCodeToEditorBuildTreeTabSelected exited");
            }
        }
        public void PutCodeIntoClipboard()
        {
            try
            {
                this.MainApp.LogMessage("Info","PutCodeIntoClipboard entered");
                Clipboard.SetText(txtCode.Text);
                this.NotifyedUser(this, new NotificationArgs() { Message = "Code copied to clipboard successfully", ImagePath = "/Images/16x16-Valid.png" });
            }
            finally
            {
                this.MainApp.LogMessage("Info","PutCodeIntoClipboard exited");
            }
        }
        public void DetermineRibbonBarMenuItemsStatus()
        {
            try
            {
                this.MainApp.LogMessage("Info","DetermineRibbonBarMenuItemsStatus entered");

                // work out what can be enabled\disabled in ribbonbar
                this.MenuArgs.Clear();
                if (this.txtCode.Text != string.Empty)
                {
                    this.MenuArgs.Add(new RibbonMenuItemArgs() { RibbonButtonName = "btnCutPasteCode", IsRibbonButtonEnabled = true });
                    this.MenuArgs.Add(new RibbonMenuItemArgs() { RibbonButtonName = "btnPrintCode", IsRibbonButtonEnabled = true });
                }
                else
                {
                    this.MenuArgs.Add(new RibbonMenuItemArgs() { RibbonButtonName = "btnCutPasteCode", IsRibbonButtonEnabled = false });
                    this.MenuArgs.Add(new RibbonMenuItemArgs() { RibbonButtonName = "btnPrintCode", IsRibbonButtonEnabled = false });
                }
                this.RibbonBarItemUpdated(this, MenuArgs);
            }
            finally
            {
                this.MainApp.LogMessage("Info","DetermineRibbonBarMenuItemsStatus exited");
            }
        }
        #endregion

        #region Control Events
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                this.MainApp.LogMessage("Info","UserControl_Loaded entered");                
            }
            finally
            {
                this.MainApp.LogMessage("Info","UserControl_Loaded exited");
            }
        }
        private void txtCode_TextChanged(object sender, System.EventArgs e)
        {
            this.MenuArgs.Clear();
            this.MenuArgs.Add(new RibbonMenuItemArgs() { RibbonButtonName = "btnSave", IsRibbonButtonEnabled = true });
            this.RibbonBarItemUpdated(this, MenuArgs);
        }
        #endregion 
    }
}
