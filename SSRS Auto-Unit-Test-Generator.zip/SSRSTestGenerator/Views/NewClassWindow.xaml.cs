﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SSRSTestGenerator.Models;

namespace SSRSTestGenerator.Views
{    
    /// <summary>
    /// Interaction logic for NewClassPropertiesWindow.xaml
    /// </summary>
    public partial class NewClassWindow : Window
    {

        public delegate void NewClassProp(object sender, ClassPropsArg arg);
        public event NewClassProp NewClassPropEvent;

        public NewClassWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClassPropsArg propArgs = new ClassPropsArg();
            propArgs.ClassProps = new ClassProperties();
            NewClassPropEvent(this, propArgs);
            this.Close();
        }
    }
}
