﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SSRSTestGenerator.Views
{
    /// <summary>
    /// Interaction logic for BrowseProjects.xaml
    /// </summary>
    public partial class BrowseProjects : Window
    {
        #region Class Variables
        public delegate void OpenProject(object sender, string projectPath);
        public event OpenProject OpenedProject;

        Microsoft.Win32.OpenFileDialog dlg = null;
        Nullable<bool> result = false;
        App MainApp { get; set; }
        #endregion

        public BrowseProjects()
        {
             try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                this.MainApp = ((App)Application.Current); // reference to logging

                this.MainApp.LogMessage("Info","BrowseProjects entered");

                InitializeComponent();

                this.MainApp = ((App)Application.Current); // reference to logging
                this.ResizeMode = ResizeMode.NoResize;
            }
             finally {
                 this.MainApp.LogMessage("Info","BrowseProjects exited");
                 Mouse.OverrideCursor = null; }
        }

        #region Private Methods
        private void btnBrowseProject_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Configure open file dialog box 
                Mouse.OverrideCursor = null;
                this.MainApp.LogMessage("Info","btnBrowseProject_Click entered");

                dlg = new Microsoft.Win32.OpenFileDialog();
                dlg.DefaultExt = ".rstp"; // Default file extension 
                dlg.Filter = "Reporting Service Test Project (.rstp)|*.rstp"; // Filter files by extension 

                // Show open file dialog box 
                result = dlg.ShowDialog();
                if (result == true)
                {
                    if (dlg.FileName.Trim() != string.Empty)
                    {
                        this.lblProjectPath.Content = dlg.FileName;
                        this.btnOpen.IsEnabled = true;
                    }
                }
            }
            finally
            {
                this.MainApp.LogMessage("Info","btnBrowseProject_Click exited");
            }
        }
        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.MainApp.LogMessage("Info","btnOpen_Click entered");

                // Process open file dialog box results 
                if (result == true)
                {
                    // Open document 
                    this.OpenedProject(this, dlg.FileName);
                }

                this.Close();
            }
            finally
            {
                this.MainApp.LogMessage("Info","btnOpen_Click exited");
            }
        }
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.MainApp.LogMessage("Info","btnCancel_Click entered");
                this.Close();
            }
            finally
            {
                this.MainApp.LogMessage("Info","btnCancel_Click exited");
            }
        }
        #endregion
    }
}
