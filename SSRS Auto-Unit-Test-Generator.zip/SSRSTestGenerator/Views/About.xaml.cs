﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SSRSTestGenerator.Views
{
    /// <summary>
    /// Interaction logic for About.xaml
    /// </summary>
    public partial class About : Window
    {
        #region Class Variables
        public delegate void ValidateKey(List<string> key);
        public event ValidateKey ValidatedKey;
        public bool IsRegistered { get; set; }

        App MainApp { get; set; }
        #endregion

        public About(bool isRegistered)
        {
            try
            {
                Mouse.OverrideCursor = null;
                                
                InitializeComponent();

                this.MainApp = ((App)Application.Current); // reference to logging
                this.MainApp.LogMessage("Info","About entered");

                this.IsRegistered = isRegistered;

                if (this.IsRegistered) // no need to register again
                {
                    this.btnRegister.IsEnabled = false;
                    this.txtBxKey1.IsEnabled = false;
                    this.txtBxKey2.IsEnabled = false;
                    this.txtBxKey3.IsEnabled = false;
                    this.txtBxKey4.IsEnabled = false;
                    this.txtBxKey5.IsEnabled = false;
                }
                
                //// testing
                //this.txtBxKey1.Text = "GHSW";
                //this.txtBxKey2.Text = "GECS";
                //this.txtBxKey3.Text = "GETD";
                //this.txtBxKey4.Text = "3CFD";
                //this.txtBxKey5.Text = "ASDF";
            }
            finally
            {
                this.MainApp.LogMessage("Info","About exited");
            }

        }
        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.MainApp.LogMessage("Info","btnOK_Click entered");
                this.Close();
            }
            finally
            {
                this.MainApp.LogMessage("Info","btnOK_Click exited");
            }
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            List<string> key = new List<string>();
            key.Add(this.txtBxKey1.Text);
            key.Add(this.txtBxKey2.Text);
            key.Add(this.txtBxKey3.Text);
            key.Add(this.txtBxKey4.Text);
            key.Add(this.txtBxKey5.Text);

            this.ValidatedKey(key);            
        }

        private void txtBxKey_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!this.IsRegistered && !String.IsNullOrEmpty(this.txtBxKey1.Text) && !String.IsNullOrEmpty(this.txtBxKey2.Text) && !String.IsNullOrEmpty(this.txtBxKey3.Text) && !String.IsNullOrEmpty(this.txtBxKey4.Text) && !String.IsNullOrEmpty(this.txtBxKey5.Text))
            {
                this.btnRegister.IsEnabled = true;
            }
            else
            {
                this.btnRegister.IsEnabled = false;
            }
        }
    }
}
