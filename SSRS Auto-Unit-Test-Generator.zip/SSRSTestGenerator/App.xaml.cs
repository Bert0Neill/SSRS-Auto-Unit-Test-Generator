﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Threading;

namespace SSRSTestGenerator
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        #region Class Variables
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #endregion

        #region Private Methods
        private void APP_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            System.Windows.MessageBox.Show(string.Format("An error occured: {0}", e.Exception.Message), "Error");

            var main = App.Current.MainWindow as MainWindow; 
            if (e.Exception.InnerException != null)
            {
                log.Error(e.Exception.InnerException.Message);
                main.UpdateNotifications(e.Exception.InnerException.Message);
            }
            else
            {
                log.Error(e.Exception.Message);
                main.UpdateNotifications(e.Exception.Message);
            }
            
            // MessageBox.Show(e.Exception.Message, "Application Error", MessageBoxButton.OK, MessageBoxImage.Error);
            e.Handled = true;
        }
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            log4net.Config.XmlConfigurator.Configure();
        }
        #endregion

        #region Public methods
        public void LogMessage(string logType, string message)
        {
            switch (logType)
            {
                case "Debug":
                    log.Debug(message);
                    break;

                case "Fatal":
                    log.Fatal(message);
                    break;

                case "Info":
                    log.Info(message);
                    break;

                case "Warn":
                    log.Warn(message);
                    break;

                case "Error":
                    log.Error(message);
                    break;

                default:
                    log.Error(message);
                    break;
            }            
        }      
        #endregion
    }
}
