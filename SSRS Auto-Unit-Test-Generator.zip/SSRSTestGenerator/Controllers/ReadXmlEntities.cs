﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Controls;
using System.Xml.Serialization;
using System.IO;

namespace SSRSTestGenerator.Controllers
{
    public class ReadXmlEntities
    {
        public void Load(string XMLFilePath, TreeView EntityModelTreeView)
        {
            XmlDocument XMLEntities;
            try
            {
                XMLEntities = new XmlDocument();
                XMLEntities.Load(XMLFilePath);

                EntityModelTreeView.Items.Clear();

                TreeViewItem root = new TreeViewItem();
                root.Header = XMLEntities.DocumentElement.Name;
                EntityModelTreeView.Items.Add(root);

                TreeViewItem ChildNode = new TreeViewItem();
                ChildNode = (TreeViewItem)EntityModelTreeView.Items[0];
                addEntityModelTreeViewNode(XMLEntities.DocumentElement, ChildNode);
                ChildNode.IsExpanded = true;

            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        private void addEntityModelTreeViewNode(XmlNode xmlEntityNode, TreeViewItem TreeViewNodes)
        {
            XmlNode entityModelXMLNode;
            TreeViewItem entityModelTreeNode;
            XmlNodeList entityModelXMLNodes;
            String entityName;

            if (xmlEntityNode.HasChildNodes)
            {
                entityModelXMLNodes = xmlEntityNode.ChildNodes;

                for (int x = 0; x <= entityModelXMLNodes.Count - 1; x++)
                {
                    string s = entityModelXMLNodes.ToString();
                    int c = entityModelXMLNodes.Count;
                    entityModelXMLNode = xmlEntityNode.ChildNodes[x];

                    string p = xmlEntityNode.Name;
                    string val = xmlEntityNode.ChildNodes[x].Name;
                    if (entityModelXMLNode.Name == "Entity")
                    {
                        entityName = entityModelXMLNode.Attributes["Name"].InnerText;

                        int i = TreeViewNodes.Items.Add(new TreeViewItem()
                        {
                            Header = entityName
                        });
                    }
                    else if (entityModelXMLNode.Name == "Property")
                    {
                        String AttributeName = entityModelXMLNode.Attributes["Name"].InnerText;

                        int i = TreeViewNodes.Items.Add(new TreeViewItem()
                        {
                            Header = AttributeName
                        });
                    }
                    else
                    {
                        int i = TreeViewNodes.Items.Add(new TreeViewItem()
                        {
                            Header = entityModelXMLNode.Name
                        });
                    }

                    entityModelTreeNode = TreeViewNodes.Items[x] as TreeViewItem;
                    addEntityModelTreeViewNode(entityModelXMLNode, entityModelTreeNode);
                    entityModelTreeNode.IsExpanded = true;
                }
            }
        }

        public string SerializeObjectToXML(object item)
        {
            try
            {
                string xmlText;
                Type objectType = item.GetType();
                XmlSerializer xmlSerializer = new XmlSerializer(objectType);
                MemoryStream memoryStream = new MemoryStream();
                using (XmlTextWriter xmlTextWriter =
                    new XmlTextWriter(memoryStream, Encoding.UTF8) { Formatting = Formatting.Indented })
                {
                    xmlSerializer.Serialize(xmlTextWriter, item);
                    memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
                    xmlText = new UTF8Encoding().GetString(memoryStream.ToArray());
                    memoryStream.Dispose();
                    return xmlText;
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.Write(e.ToString());
                return null;
            }
        }

        public object DeserializeXMLToObject(string xmlText, Type objectType)
        {
            if (string.IsNullOrEmpty(xmlText)) return null;
            XmlSerializer xs = new XmlSerializer(objectType);
            using (MemoryStream memoryStream = new MemoryStream(new UTF8Encoding().GetBytes(xmlText)))
            {
                return xs.Deserialize(memoryStream);
            }
        }
    }
}

