﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class NodeDetails
    {
        public NodeDetails() { NodeID = Guid.NewGuid(); }

        public Guid NodeID { get; set; } //unique ID
        public string ClassName { get; set; }
        public string NodeName { get; set; }
        public int NodeIndex { get; set; }
        public List<string> Attributes { get; set; }
        public List<NodeAssertions> Assertions { get; set; }
        public string XPath { get; set; }
    }    
}
