﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class ReportCredentials
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Domian { get; set; }
    }
}
