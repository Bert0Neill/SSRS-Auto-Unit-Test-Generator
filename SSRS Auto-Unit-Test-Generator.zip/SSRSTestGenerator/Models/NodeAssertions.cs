﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class NodeAssertions
    {

        public NodeAssertions() { this.ID = Guid.NewGuid(); }

        public Guid ID { get; set; }        
        public string Attribute { get; set; }        
        public string Value { get; set; }
        public string ListBoxValueOfAssertion { get; set; }
        public object Assertion { get; set; }
        // public NUnitAssertions NunitAssertion { get; set; }

        public Assertions clsAssertion { get; set; }
    }

    public enum MSAssertions
    {
        AreEqual,
        AreNotEqual,     
        Contains,
        DoesNotMatch,
        EndsWith,
        Matches,
        StartsWith
    }

    public enum NUnitAssertions
    {
          Contains,
          DoesNotContain,
          StartsWith,
          DoesNotStartWith,
          EndsWith,
          DoesNotEndWith,     
          AreEqualIgnoringCase,
          AreNotEqualIgnoringCase          
    }
}
