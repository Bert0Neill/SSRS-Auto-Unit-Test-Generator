﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Reporting.WinForms.Internal.Soap.ReportingServices2005.Execution;

namespace SSRSTestGenerator.Models
{
    public class ReportXmlArgs:EventArgs
    {
        private string reportXml = string.Empty;
        public string ReportXml
        {
            get { return reportXml; }
            set { reportXml = value; }
        }

        private ParameterValue[] reportParameters = null;
        public ParameterValue[] ReportParameters
        {
            get { return reportParameters; }
            set { reportParameters = value; }
        }

        public ReportXmlArgs(string xml, ParameterValue[] reportParams)
        {
            this.ReportXml = xml;
            this.ReportParameters = reportParams;
        }
    }
}
