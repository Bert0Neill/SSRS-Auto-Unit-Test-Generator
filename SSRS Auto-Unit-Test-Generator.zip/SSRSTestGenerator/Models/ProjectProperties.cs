﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class ProjectProperties
    {
        public ProjectProperties() { Id = Guid.NewGuid(); }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ProjectSavedPath { get; set; }
        public ClassEnumerations.CodeLanguages Language { get; set; }
        public ClassEnumerations.TestFrameworks TestFramework { get; set; }
        public string ReportWebServiceUrl { get; set; }
        public string ReportServerUrl { get; set; }
        public DateTime ProjectCraeted { get; set; }
        public int TotalProjectTests { get; set; }        

        public List<ClassProperties> ClassProperties { get; set; }
    }
}
