﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class ClassEnumerations
    {
        public enum TestFrameworks
        {
            NUnit,
            VSTest            
        }

        public enum CodeLanguages
        {
            CSharp,
            VB
        }

        public enum ApplicationType
        {
            Project,
            Class
        }

        public enum ApplicationStatus
        {
            New,
            Update
        }
    }
}
