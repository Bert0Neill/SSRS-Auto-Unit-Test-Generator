﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Reporting.WinForms.Internal.Soap.ReportingServices2005.Execution;

namespace SSRSTestGenerator.Models
{
    public class ClassProperties
    {
        public ClassProperties() { Id = Guid.NewGuid(); }

        public Guid Id { get; set; }
        public string Name { get; set; }        
        public string ReportName { get; set; }
        public string ReportFolder { get; set; }
        public DateTime ClassCraeted { get; set; }
        public int NumberOfClassTests { get; set; }
        public ReportCredentials Credentials { get; set; }
        public ParameterValue[] ReportParameters { get; set; }
        public bool IsEdited { get; set; }
        public List<NodeDetails> TreeNodeAssertionDetails { get; set; }
        public string Code { get; set; }
        public string Xml { get; set; }
    }
}
