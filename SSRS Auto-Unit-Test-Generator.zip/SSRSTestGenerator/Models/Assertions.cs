﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class Assertions
    {
        public string AssertionName { get; set; }
        public bool IsAssertionNeedingRegex { get; set; }
        public string AssertMemberName { get; set; }
    }    
}
