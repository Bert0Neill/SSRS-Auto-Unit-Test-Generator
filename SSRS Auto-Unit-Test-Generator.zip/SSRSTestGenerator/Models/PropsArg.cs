﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class PropsArg
    {
        public PropsArg() { this.IsUpdated = false; }

        public object Properties { get; set; }
        public SSRSTestGenerator.Models.ClassEnumerations.ApplicationType AppTypeObject { get; set; }
        public bool IsUpdated { get; set; }
    }
}
