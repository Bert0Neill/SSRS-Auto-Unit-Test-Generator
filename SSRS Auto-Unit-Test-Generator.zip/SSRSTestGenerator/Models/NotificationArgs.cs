﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class NotificationArgs
    {
        public NotificationArgs() { this.ImagePath = "/Images/16x16-Information.png"; }

        public string Message { get; set; }
        public string ImagePath { get; set; }
        public string Sender { get; set; }
    }
}
