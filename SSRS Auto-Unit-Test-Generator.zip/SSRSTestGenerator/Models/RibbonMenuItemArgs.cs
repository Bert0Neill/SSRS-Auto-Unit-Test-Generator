﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class RibbonMenuItemArgs
    {
        public string RibbonButtonName {get; set;}
        public bool IsRibbonButtonEnabled { get; set; }
    }
}
