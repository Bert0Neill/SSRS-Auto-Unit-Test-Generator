﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class NodeIndex
    {
        public string NodeName { get; set; }
        public int CurrentIndex { get; set; }
    }
}
