﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class StatusProgressBarArgs
    {
        public string StatusBarValue { get; set; }
        public int ProgressBarValue { get; set; } // min = 0, max = 100        
    }
}
