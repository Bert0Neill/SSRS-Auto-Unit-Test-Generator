﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class TestCodeArgs : EventArgs
    {
        private string reportCode = string.Empty;
        public string ReportCode
            {
                get { return reportCode; }
                set { reportCode = value; }
            }
        public TestCodeArgs(string code)
            {
                this.ReportCode = code;
            }
    }
    
}
