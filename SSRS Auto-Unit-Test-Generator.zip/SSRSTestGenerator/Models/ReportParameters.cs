﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSRSTestGenerator.Models
{
    public class ReportParameters
    {
        public ReportParameters()
        {
            this.Prompt = this.DefaultValues = this.Type = this.Name = this.Value = string.Empty;
            this.AllowBlank = false;
        }

        public string Name { get; set; }
        public string Value { get; set; }
        public string Type { get; set; }
        public bool AllowBlank { get; set; }
        public string DefaultValues { get; set; }
        public string Prompt { get; set; }
    }
}
