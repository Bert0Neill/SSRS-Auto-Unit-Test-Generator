﻿namespace SSRSTestGenerator.Models.ProjectProperties.TestClasses
{
    using System;
    using System.IO;
    using System.Xml;
    using Microsoft.Reporting.WebForms.Internal.Soap.ReportingServices2005.Execution;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Xml.XPath;
    using System.Xml.Linq;
    using System.Text.RegularExpressions;

    [TestClass]
    public class Params
    {
        public Params() { }


       #region Class Variables
        string format = "xml", devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
        byte[] reportResult = null;
        string reportNamePath = string.Empty, reportHeaderTextBx = string.Empty, reportTitleTextBx = string.Empty, reportExecutionTimeTextBx = string.Empty, reportPagingTextBx = string.Empty;
        string reportService = "http://developer-pc/ReportServer/ReportExecution2005.asmx"; // ReportExecution2005 url
        Microsoft.Reporting.WebForms.Internal.Soap.ReportingServices2005.Execution.Warning[] warnings = null;
        string encoding = null, mimeType = null, extension = null, historyID = null;
        ReportExecutionService reportExecService = null;
        ExecutionInfo execInfo = null;
        ExecutionHeader execHeader = null;
        MemoryStream reportStream = null;
        XmlDocument reportXml = null;
        string[] streamIDs = null;
        ParameterValue[] parameters = null;
        #endregion

        #region Class Private Methods
        private void CheckReportWarnings()
        {
            // check for report rendering issues
            if (warnings != null)
            {
                string warning = "Report returned with warning(s). " + Environment.NewLine + Environment.NewLine;
                foreach (Warning warn in warnings)
                {
                    warning += "Message: " + warn.Message + " Severity: " + warn.Severity + " Object Name: " + warn.ObjectName + Environment.NewLine;
                }
                Assert.Fail(warning);
            }
        }
        private void LoadStreamIntoXmlObject()
        {
            this.reportStream = new MemoryStream();
            this.reportStream.Write(this.reportResult, 0, this.reportResult.Length);
            this.reportStream.Position = 0;
            this.reportXml = new XmlDocument();
            this.reportXml.Load(this.reportStream);

			// remove namespace
            string xml = this.reportXml.InnerXml;            
            var dom = new XmlDocument();
            dom.LoadXml(xml);
            var loaded = new XDocument();
            if (dom.DocumentElement != null)
            {
                if (dom.DocumentElement.NamespaceURI != String.Empty)
                {
                    dom.LoadXml(dom.OuterXml.Replace(dom.DocumentElement.NamespaceURI, String.Empty));
                    dom.DocumentElement.RemoveAllAttributes();
                    loaded = XDocument.Parse(dom.OuterXml);
                    this.reportXml = new XmlDocument(); // added last
                    this.reportXml.LoadXml(loaded.ToString()); //laod xml without namespaces    
                }                
            }
        }
        #endregion

        #region Setup
        [TestInitializeAttribute]
        public void Setup()
        {
            this.reportExecService = new ReportExecutionService();
            this.reportExecService.Credentials = System.Net.CredentialCache.DefaultCredentials;
            this.reportExecService.Url = this.reportService;
            this.execInfo = new ExecutionInfo();
            this.execHeader = new ExecutionHeader();
            this.reportExecService.ExecutionHeaderValue = this.execHeader;

            if (this.reportResult == null) 
            {             
                this.reportNamePath = "/Cars/Cars"; // replace with report and path

                #region Report Parameters
					this.parameters = new ParameterValue[3];

				this.parameters[0] = new ParameterValue();
				this.parameters[0].Name = "TextParam_1"; 
				this.parameters[0].Value = "Ford";
				this.parameters[1] = new ParameterValue();
				this.parameters[1].Name = "IntParam_2"; 
				this.parameters[1].Value = "101";
				this.parameters[2] = new ParameterValue();
				this.parameters[2].Name = "TextParam_3"; 
				this.parameters[2].Value = "$1200";
                #endregion

                this.execInfo = this.reportExecService.LoadReport(this.reportNamePath, this.historyID);
                this.reportExecService.SetExecutionParameters(this.parameters, string.Empty);

                try
                {
                    this.reportResult = this.reportExecService.Render(this.format, this.devInfo, out this.extension, out this.encoding, out this.mimeType, out this.warnings, out this.streamIDs);
                    this.CheckReportWarnings();
                    this.LoadStreamIntoXmlObject(); 
                }
                catch (Exception ex)
                {
                    Assert.Fail(ex.Message);
                }
            }
        }
        #endregion		

        #region auto generated tests
         
		[TestMethod]
		public void Trademark_AreEqual_Jaguar()
		{
		   try
		     {
		       	 Assert.AreEqual(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, "Jaguar");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_AreNotEqual_Jag()
		{
		   try
		     {
		       	 Assert.AreNotEqual(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, "Jag");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_Contains_Jag()
		{
		   try
		     {
		       	 StringAssert.Contains(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, "Jag");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_DoesNotMatch_wsFord()
		{
		   try
		     {
		       	 StringAssert.DoesNotMatch(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, new Regex(@"(\w+)\s+(Ford)"));
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_EndsWith_ar()
		{
		   try
		     {
		       	 StringAssert.EndsWith(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, "ar");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_Matches_AZaz()
		{
		   try
		     {
		       	 StringAssert.Matches(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, new Regex(@"[A-Za-z]"));
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_StartsWith_Ja()
		{
		   try
		     {
		       	 StringAssert.StartsWith(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[6]/@Trademark").Value, "Ja");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}

        #endregion



    }
}

