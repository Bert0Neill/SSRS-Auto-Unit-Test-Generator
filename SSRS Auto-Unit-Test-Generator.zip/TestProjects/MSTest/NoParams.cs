﻿namespace SSRSTestGenerator.Models.ProjectProperties.TestClasses
{
    using System;
    using System.IO;
    using System.Xml;
    using Microsoft.Reporting.WebForms.Internal.Soap.ReportingServices2005.Execution;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Xml.XPath;
    using System.Xml.Linq;
    using System.Text.RegularExpressions;

    [TestClass]
    public class NoParams
    {
        public NoParams() { }

        #region Class Variables
        string format = "xml", devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
        byte[] reportResult = null;
        string reportNamePath = string.Empty, reportHeaderTextBx = string.Empty, reportTitleTextBx = string.Empty, reportExecutionTimeTextBx = string.Empty, reportPagingTextBx = string.Empty;
        string reportService = "http://developer-pc/ReportServer/ReportExecution2005.asmx"; // ReportExecution2005 url
        Microsoft.Reporting.WebForms.Internal.Soap.ReportingServices2005.Execution.Warning[] warnings = null;
        string encoding = null, mimeType = null, extension = null, historyID = null;
        ReportExecutionService reportExecService = null;
        ExecutionInfo execInfo = null;
        ExecutionHeader execHeader = null;
        MemoryStream reportStream = null;
        XmlDocument reportXml = null;
        string[] streamIDs = null;
        ParameterValue[] parameters = null;
        #endregion

        #region Class Private Methods
        private void CheckReportWarnings()
        {
            // check for report rendering issues
            if (warnings != null)
            {
                string warning = "Report returned with warning(s). " + Environment.NewLine + Environment.NewLine;
                foreach (Warning warn in warnings)
                {
                    warning += "Message: " + warn.Message + " Severity: " + warn.Severity + " Object Name: " + warn.ObjectName + Environment.NewLine;
                }
                Assert.Fail(warning);
            }
        }
        private void LoadStreamIntoXmlObject()
        {
            this.reportStream = new MemoryStream();
            this.reportStream.Write(this.reportResult, 0, this.reportResult.Length);
            this.reportStream.Position = 0;
            this.reportXml = new XmlDocument();
            this.reportXml.Load(this.reportStream);

			// remove namespace
            string xml = this.reportXml.InnerXml;            
            var dom = new XmlDocument();
            dom.LoadXml(xml);
            var loaded = new XDocument();
            if (dom.DocumentElement != null)
            {
                if (dom.DocumentElement.NamespaceURI != String.Empty)
                {
                    dom.LoadXml(dom.OuterXml.Replace(dom.DocumentElement.NamespaceURI, String.Empty));
                    dom.DocumentElement.RemoveAllAttributes();
                    loaded = XDocument.Parse(dom.OuterXml);
                    this.reportXml = new XmlDocument(); // added last
                    this.reportXml.LoadXml(loaded.ToString()); //laod xml without namespaces    
                }                
            }
        }
        #endregion

        #region Setup
        [TestInitializeAttribute]
        public void Setup()
        {
            this.reportExecService = new ReportExecutionService();
            this.reportExecService.Credentials = System.Net.CredentialCache.DefaultCredentials;
            this.reportExecService.Url = this.reportService;
            this.execInfo = new ExecutionInfo();
            this.execHeader = new ExecutionHeader();
            this.reportExecService.ExecutionHeaderValue = this.execHeader;

            if (this.reportResult == null) 
            {             
                this.reportNamePath = "/Cars/CarsNoParams"; // replace with report and path

                #region Report Parameters
			this.parameters = new ParameterValue[0];
                #endregion

                this.execInfo = this.reportExecService.LoadReport(this.reportNamePath, this.historyID);
                this.reportExecService.SetExecutionParameters(this.parameters, string.Empty);

                try
                {
                    this.reportResult = this.reportExecService.Render(this.format, this.devInfo, out this.extension, out this.encoding, out this.mimeType, out this.warnings, out this.streamIDs);
                    this.CheckReportWarnings();
                    this.LoadStreamIntoXmlObject(); 
                }
                catch (Exception ex)
                {
                    Assert.Fail(ex.Message);
                }
            }
        }
        #endregion		

        #region auto generated tests
         
		[TestMethod]
		public void Trademark_AreEqual_BMW()
		{
		   try
		     {
		       	 Assert.AreEqual(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "BMW");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_AreNotEqual_XXX()
		{
		   try
		     {
		       	 Assert.AreNotEqual(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "XXX");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_Contains_BM()
		{
		   try
		     {
		       	 StringAssert.Contains(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "BM");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_EndsWith_W()
		{
		   try
		     {
		       	 StringAssert.EndsWith(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "W");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_StartsWith_B()
		{
		   try
		     {
		       	 StringAssert.StartsWith(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "B");
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_DoesNotMatch_wscar()
		{
		   try
		     {
		       	 StringAssert.DoesNotMatch(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, new Regex(@"(\w+)\s+(car)"));
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}
		[TestMethod]
		public void Trademark_Matches_AZaz()
		{
		   try
		     {
		       	 StringAssert.Matches(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, new Regex(@"[A-Za-z]"));
		     }
		     catch(Exception ex) { Assert.Fail(ex.Message); }
		}

        #endregion
       



    }
}

