﻿namespace NunitTests
{
    using System;
    using System.IO;
    using System.Xml;
    using Microsoft.Reporting.WebForms.Internal.Soap.ReportingServices2005.Execution;
    using NUnit.Framework;
    using System.Xml.XPath;
    using System.Xml.Linq;
 
  [TestFixture]
  public class Params
  {
		public Params() {}
        #region Class Variables
        string format = "xml", devInfo = @"<DeviceInfo><Toolbar>False</Toolbar></DeviceInfo>";
        byte[] reportResult = null;
        string reportNamePath = string.Empty, reportHeaderTextBx = string.Empty, reportTitleTextBx = string.Empty, reportExecutionTimeTextBx = string.Empty, reportPagingTextBx = string.Empty;
        string reportService = "http://developer-pc/ReportServer/ReportExecution2005.asmx"; // ReportExecution2005 url
        Microsoft.Reporting.WebForms.Internal.Soap.ReportingServices2005.Execution.Warning[] warnings = null;
        string encoding = null, mimeType = null, extension = null, historyID = null;
        ReportExecutionService reportExecService = null;
        ExecutionInfo execInfo = null;
        ExecutionHeader execHeader = null;
        MemoryStream reportStream = null;
        XmlDocument reportXml = null;
        string[] streamIDs = null;
        ParameterValue[] parameters = null;
        #endregion

        #region Class Private Methods
        private void CheckReportWarnings()
        {
            // check for report rendering issues
            if (warnings != null)
            {
                string warning = "Report returned with warning(s). " + Environment.NewLine + Environment.NewLine;
                foreach (Warning warn in warnings)
                {
                    warning += "Message: " + warn.Message + " Severity: " + warn.Severity + " Object Name: " + warn.ObjectName + Environment.NewLine;
                }
                Assert.Fail(warning);
            }
        }
        private void LoadStreamIntoXmlObject()
        {
            this.reportStream = new MemoryStream();
            this.reportStream.Write(this.reportResult, 0, this.reportResult.Length);
            this.reportStream.Position = 0;
            this.reportXml = new XmlDocument();
            this.reportXml.Load(this.reportStream);

            // remove namespace
            string xml = this.reportXml.InnerXml;
            var dom = new XmlDocument();
            dom.LoadXml(xml);
            var loaded = new XDocument();
            if (dom.DocumentElement != null)
            {
                if (dom.DocumentElement.NamespaceURI != String.Empty)
                {
                    dom.LoadXml(dom.OuterXml.Replace(dom.DocumentElement.NamespaceURI, String.Empty));
                    dom.DocumentElement.RemoveAllAttributes();
                    loaded = XDocument.Parse(dom.OuterXml);
                    this.reportXml = new XmlDocument(); // added last
                    this.reportXml.LoadXml(loaded.ToString()); //laod xml without namespaces    
                }
            }
        }
        #endregion

        #region Setup
        [SetUp]
        public void Setup()
        {
            this.reportExecService = new ReportExecutionService();
            this.reportExecService.Credentials = System.Net.CredentialCache.DefaultCredentials;
            this.reportExecService.Url = this.reportService;
            this.execInfo = new ExecutionInfo();
            this.execHeader = new ExecutionHeader();
            this.reportExecService.ExecutionHeaderValue = this.execHeader;

            if (this.reportResult == null)
            {
                this.reportNamePath = "/Cars/Cars"; // replace with report and path

                #region Report Parameters
                this.parameters = new ParameterValue[3];

                this.parameters[0] = new ParameterValue();
                this.parameters[0].Name = "TextParam_1";
                this.parameters[0].Value = "Ford";
                this.parameters[1] = new ParameterValue();
                this.parameters[1].Name = "IntParam_2";
                this.parameters[1].Value = "100";
                this.parameters[2] = new ParameterValue();
                this.parameters[2].Name = "TextParam_3";
                this.parameters[2].Value = "$1200";
                #endregion

                this.execInfo = this.reportExecService.LoadReport(this.reportNamePath, this.historyID);
                this.reportExecService.SetExecutionParameters(this.parameters, string.Empty);

                try
                {
                    this.reportResult = this.reportExecService.Render(this.format, this.devInfo, out this.extension, out this.encoding, out this.mimeType, out this.warnings, out this.streamIDs);
                    this.CheckReportWarnings();
                    this.LoadStreamIntoXmlObject();
                }
                catch (Exception ex)
                {
                    Assert.Fail(ex.Message);
                }
            }
        }
        #endregion


        [Test]
        public void Trademark_AreEqualIgnoringCase_bmw()
        {
            StringAssert.AreEqualIgnoringCase(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "bmw");
        }

        [Test]
        public void Trademark_AreNotEqualIgnoringCase_bmw2()
        {
            StringAssert.AreNotEqualIgnoringCase(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "bmw2");
        }

        [Test]
        public void Trademark_Contains_BM()
        {
            StringAssert.Contains("BM", this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value);
        }

        [Test]
        public void Trademark_DoesNotContain_xxx()
        {
            StringAssert.DoesNotContain(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "xxx");
        }

        [Test]
        public void Trademark_DoesNotEndWith_XXX()
        {
            StringAssert.DoesNotEndWith(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "XXX");
        }

        [Test]
        public void Trademark_DoesNotStartWith_xxx()
        {
            StringAssert.DoesNotStartWith(this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value, "xxx");
        }

        [Test]
        public void Trademark_EndsWith_W()
        {
            StringAssert.EndsWith("W", this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value);
        }

        [Test]
        public void Trademark_StartsWith_B()
        {
            StringAssert.StartsWith("B", this.reportXml.SelectSingleNode("/Report/Tablix1[1]/Details_Collection[1]/Details[4]/@Trademark").Value);
        }

  }
}